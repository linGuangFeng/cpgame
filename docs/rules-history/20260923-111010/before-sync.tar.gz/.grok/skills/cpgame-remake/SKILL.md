---
name: cpgame-remake
description: >
  CPGame 复刻实现：Java 规则核心、generator、controller、Redis Loader、原页面试玩验收。
  Use when the user says 复刻, generator, controller, runRedis, 试玩验收,
  demo 坏了, 检查所有游戏, redis 参考 1809, or runs /cpgame-remake.
---

# 复刻

长流程按仓库根目录 `复刻要求.md` 执行。下面几条覆盖该文档里已经过时或容易做错的点。

## Redis

连接只抄 `generator/1809-mac-Freedom-Day/dist/generator.properties` 的 `redis.host` / `port` / `database` / `username` / `password` / `ssl` / 超时。不要用 `复刻要求.md` 第八节的 `192.168.10.3:6379` DB 15。

`redis.game-id` 保持各游戏现有值（页面 ID + 8000000 的那套）。Key 规则、ZADD+RPUSH+LTRIM、`#` 无奖标记、Demo 目标倍率向下查找，仍按 `复刻要求.md`。

Controller 若校验或写死旧 Redis 地址，改源码后必须重打包 `server-api/<游戏>/dist` 的 JAR，只改 properties 不够。

## 试玩坏了

默认是进原页面后的 init/spin/结算，不是进程没起来。远程 Redis 禁止全量 ZRANGE 再逐桶 LLEN。超时要读 `redis.socket-timeout-ms`（默认 30000），不要用 300ms。

有缓存就必须能转；空池对无数据游戏是合同。不要把空池当成入口故障。

## 核心文件 vs 彩虹表

核心（拷到其他项目）：`GameRuleCore`、`ResultUtil`、Codec、0 倍生成器、`server-api/*/dist/controller.jar`。

禁止打进核心：`*joint-kernels.txt`、`*column-model.tsv`、`dealing-model.json`、`deal-model.json`、`generation-model*.tsv`、`*-distribution.tsv`、`reel-model.json` 及同类抓包频数表。这些只给 Redis Loader 灌数、测试、验证或 `reports/` 留底。Controller 不得 `getResourceAsStream` 这些文件，`dist/controller.jar` 不得含这些条目。`server-api/*/src/main/resources` 不得放这些表。

Demo：中奖读 Redis；已判定 0 倍走 0 倍生成器，不查 Redis 0 桶。不要把 generator 的 shaded jar 拷进 `server-api/*/dist`。

## 交付

- Controller：`server-api/<ID>-<Name>/dist/controller.jar` + `demo-controller.properties`，contract v3，端口 50000–59999 由平台注入。
- Loader：`generator/<ID>-<Name>/dist` 一个 shaded JAR、无 seed 的 `generator.properties`、可双击的 `.cmd`。Loader 可以带灌数用表，Controller 不行。
- 静态包是 `publish/<ID>-<Name>`，不是 `resources/`。

需要把 publish 或补好的静态资源传到 CDN 时，用 `.grok/skills/cpgame-s3-upload/SKILL.md`。
