# CPGame 项目规则

详细流程不写在本文件。长文仍以仓库根目录 `抓包要求.md`、`复刻要求.md` 为准；本文件只放每次会话都要遵守的硬约束。

## 试玩

- 用户说 demo / 试玩坏了：默认是进原页面后 init/spin/结算报错，不是进程起不来。
- 不能用首页 HTTP 200、截图或 Get Started 代替验收。必须对真实 spin API 或原页面点 Spin。
- Redis 为空时付费 spin 明确失败是合同，不是入口挂了。有缓存的游戏必须能转。

## Redis

- 连接以 `generator/1809-mac-Freedom-Day/dist/generator.properties` 为准（host/port/database/username/password/ssl/超时）。不要用 `复刻要求.md` 第八节里的旧 `192.168.10.3:6379` DB 15。
- 只改连接，不改各游戏 `redis.game-id`。
- 不要只改 properties。Controller 若写死旧 Redis 地址，必须改源码并重打包 `server-api/<游戏>/dist` 里的 JAR。
- `generator.properties` 注释按 1809 分段写清含义。

## generator.properties 分段

- 相关配置必须挨在一起，按 1809：连接 → game-id → 生成数量/批次 → 每桶保留条数 → 连赢/免费上限 → **倍数 min/max 整段** → 牌面权重。
- 禁止把 `normal-min` 插进权重中间、`normal-max` 丢在文件末尾。
- 数字不准改。只重排和补分段注释。

## 最小倍数配置

- Redis 灌库最小倍数看 `dist/generator.properties` 里已有键：`generation.normal-min-win-multiplier` / `special-min` / `mary-min`，或该游戏自己的 `range.normal-min`、`generation.min-win-multiplier`。
- **缺 key 才补**。已有数字一律不改。注释写 100、配置写 50 只要意思对就算对。
- 58 只用 `generation.min-win-multiplier`，禁止再写 `generation.normal-min-*` / `special-min-*`（会启动失败）。2470 用 `range.normal-min` / `range.special-min`。

## 打包必须进 dist

- 用户跑的是 `generator/<游戏>/dist/*.jar` 和 `server-api/<游戏>/dist/controller.jar`，不是 `target/`。
- `mvn package` 成功不等于 dist 已更新。pom 若没有 copy/outputFile 到 dist，必须亲手覆盖 dist，并核对该文件的修改时间。
- 改 Loader 循环、清库、key 合同之后，必须把**所有改过的游戏**都拷进各自 dist，禁止只处理其中一个。
- 没核过 dist 时间戳，不准声称「已经改好、用新包再开」。

## 抓包与补资源

- 用户说抓包、补资源、抓遗漏、缺图/缺音频/静态 404：先读并执行 `.grok/skills/cpgame-capture/SKILL.md`。
- 用户没给厅账号时，用该 skill 里的默认账号。给了账号则用用户的。
- 已有有效 resources/captures/fixtures/publish 必须复用，只补缺口。
- 补漏静态资源完成后，必须按 `.grok/skills/cpgame-s3-upload/SKILL.md` 上传到 S3，不用再问。

## 复刻

- 用户说复刻、generator、controller、runRedis、试玩验收：读并执行 `.grok/skills/cpgame-remake/SKILL.md`。
- 服务端 API、完整局生成器、规则核心、ResultUtil、Redis Loader 只用 Java。一套 GameRuleCore，三处共用。
- Demo 结果只从 Redis 预生成完整局读取，禁止当场生成整局或用 fixtures 顶 Redis。已判定 0 倍时走共享 0 倍生成器，不查 Redis 0 桶。
- 抓包频数表、joint-kernels、column-model、dealing-model、generation-model 等彩虹表：可以给 Redis Loader 灌数、测试、验证或留底。禁止放进核心文件。核心是要拷到其他项目的 Java 规则（GameRuleCore、ResultUtil、Codec、0 倍生成器）和 `server-api/*/dist/controller.jar`。Controller 与 GameRuleCore 不得加载或打包这些表。发牌按规则+上限构造，不要把直方图打进核心。
